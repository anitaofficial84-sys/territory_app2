import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart' show defaultTargetPlatform;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'hex_grid.dart';

const _cellsKey = 'territory_hex_cells'; // v0.2 hex cells (old square cells ignored)
const _activitiesKey = 'territory_activities';
const _coinsKey = 'territory_coins';
const _xpKey = 'territory_king_xp';
const _carryKey = 'territory_coin_carry_m';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TerritoryApp());
}

class TerritoryApp extends StatelessWidget {
  const TerritoryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TERRITORY',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090D12),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFB8F36B),
          secondary: Color(0xFF72D6C5),
          surface: Color(0xFF121922),
        ),
        useMaterial3: true,
      ),
      home: const TerritoryHome(),
    );
  }
}

class TerritoryHome extends StatefulWidget {
  const TerritoryHome({super.key});

  @override
  State<TerritoryHome> createState() => _TerritoryHomeState();
}

class _TerritoryHomeState extends State<TerritoryHome> {
  final MapController _map = MapController();
  StreamSubscription<Position>? _gps;
  final List<LatLng> _route = [];
  final Set<String> _claimed = {};
  List<Polygon> _polygons = const [];
  LatLng _center = const LatLng(29.1492, 75.7217); // Hisar fallback; GPS replaces this.
  bool _recording = false;
  bool _loading = true;
  String _status = 'Getting location…';
  double _distanceKm = 0;
  double _lastAccuracy = 0;
  DateTime? _started;
  int _rejected = 0;
  int _newCells = 0;
  int _coins = 0;
  int _kingXp = 0;
  double _carryM = 0; // metres not yet turned into a coin (100 m = 1 coin)
  double _moveSeconds = 0; // moving time not yet turned into XP
  bool _mapReady = false;
  String? _candidateCell;
  int _candidateHits = 0;

  @override
  void initState() {
    super.initState();
    _loadLocalState();
    _prepareLocation();
  }

  Future<void> _loadLocalState() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList(_cellsKey) ?? [];
    final coins = prefs.getInt(_coinsKey) ?? 0;
    final xp = prefs.getInt(_xpKey) ?? 0;
    final carry = prefs.getDouble(_carryKey) ?? 0;
    if (!mounted) return;
    setState(() {
      _claimed.addAll(saved);
      _coins = coins;
      _kingXp = xp;
      _carryM = carry;
      _polygons = _buildCellPolygons();
      _loading = false;
    });
  }

  Future<void> _prepareLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _setStatus('Location is off. Turn on GPS to explore.');
      return;
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.deniedForever) {
      _setStatus('Location blocked. Enable it in app settings.');
      await Geolocator.openAppSettings();
      return;
    }
    if (permission == LocationPermission.denied) {
      _setStatus('Location permission is required to record a route.');
      return;
    }
    try {
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (!mounted) return;
      setState(() {
        _center = LatLng(p.latitude, p.longitude);
        _lastAccuracy = p.accuracy;
        _status = 'Ready to explore';
      });
      _moveMap(_center, 16);
    } catch (_) {
      _setStatus('Could not get GPS fix. Try outdoors.');
    }
  }

  void _setStatus(String value) {
    if (mounted) setState(() => _status = value);
  }

  Future<void> _toggleRecording() async {
    if (_recording) {
      await _gps?.cancel();
      _gps = null;
      await _saveCells();
      await _saveProgress();
      await _saveActivity();
      if (!mounted) return;
      setState(() {
        _recording = false;
        _status = 'Activity saved on this phone';
      });
      return;
    }

    final permission = await Geolocator.checkPermission();
    if (permission != LocationPermission.whileInUse &&
        permission != LocationPermission.always) {
      await _prepareLocation();
      return;
    }

    setState(() {
      _recording = true;
      _started = DateTime.now();
      _lastTimestamp = null;
      _route.clear();
      _distanceKm = 0;
      _rejected = 0;
      _newCells = 0;
      _moveSeconds = 0;
      _candidateCell = null;
      _candidateHits = 0;
      _status = 'Recording activity';
    });

    // On Android, a foreground service keeps GPS recording alive when the
    // screen is locked or the app is in the background.
    final LocationSettings settings =
        defaultTargetPlatform == TargetPlatform.android
            ? AndroidSettings(
                accuracy: LocationAccuracy.best,
                distanceFilter: 5,
                foregroundNotificationConfig: const ForegroundNotificationConfig(
                  notificationTitle: 'TERRITORY',
                  notificationText: 'Recording your exploration',
                  notificationChannelName: 'Activity recording',
                  enableWakeLock: true,
                  setOngoing: true,
                ),
              )
            : const LocationSettings(
                accuracy: LocationAccuracy.best,
                distanceFilter: 5,
              );
    _gps = Geolocator.getPositionStream(locationSettings: settings).listen(
      _onPosition,
      onError: (_) => _setStatus('GPS stream interrupted'),
    );
  }

  void _onPosition(Position p) {
    if (!mounted) return;
    // Conservative prototype filters: reject poor accuracy and implausible jumps.
    if (p.accuracy > 25) {
      setState(() => _rejected++);
      return;
    }
    final point = LatLng(p.latitude, p.longitude);
    if (_route.isNotEmpty) {
      final previous = _route.last;
      final meters = const Distance().as(LengthUnit.Meter, previous, point);
      final now = p.timestamp ?? DateTime.now();
      final last = _lastTimestamp;
      final seconds =
          last == null ? 0.0 : now.difference(last).inMilliseconds / 1000;
      // Reject implausible jumps (> ~43 km/h) and duplicate/out-of-order fixes.
      if (last != null && seconds <= 0) {
        return;
      }
      if (seconds > 0 && meters / seconds > 12) {
        setState(() => _rejected++);
        return;
      }
      _distanceKm += meters / 1000;
      // Rewards: 1 coin per 100 m. King XP = 1 per 100 m + 1 per moving minute.
      _carryM += meters;
      final earned = _carryM ~/ 100;
      var xpGain = earned;
      if (seconds > 0 && meters / seconds >= 0.5) {
        _moveSeconds += seconds;
        final mins = _moveSeconds ~/ 60;
        if (mins > 0) {
          xpGain += mins;
          _moveSeconds -= mins * 60;
        }
      }
      if (earned > 0 || xpGain > 0) {
        _carryM -= earned * 100;
        _coins += earned;
        _kingXp += xpGain;
        _saveProgress(); // save as we go, not only on finish
      }
    }
    _lastTimestamp = p.timestamp ?? DateTime.now();
    _route.add(point);
    // Hex grid lives in hex_grid.dart (swap for H3 later without touching this).
    // A new cell counts only after 2 consecutive fixes land in it (filters GPS drift).
    final cell = HexGrid.keyFor(point);
    if (_claimed.contains(cell)) {
      _candidateCell = null;
      _candidateHits = 0;
    } else {
      if (_candidateCell == cell) {
        _candidateHits++;
      } else {
        _candidateCell = cell;
        _candidateHits = 1;
      }
      if (_candidateHits >= 2) {
        _claimed.add(cell);
        _newCells++;
        _candidateCell = null;
        _candidateHits = 0;
        _polygons = _buildCellPolygons();
        _saveCells(); // save as we go so a crash/kill does not lose progress
      }
    }
    setState(() {
      _center = point;
      _lastAccuracy = p.accuracy;
      _status = 'Exploring • ${_route.length} GPS points';
    });
    _moveMap(point, null);
  }

  /// Moving the map before FlutterMap is attached throws, so guard it.
  void _moveMap(LatLng target, double? zoom) {
    if (!_mapReady) return;
    try {
      _map.move(target, zoom ?? _map.camera.zoom);
    } catch (_) {}
  }

  DateTime? _lastTimestamp;

  Future<void> _saveProgress() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_coinsKey, _coins);
      await prefs.setInt(_xpKey, _kingXp);
      await prefs.setDouble(_carryKey, _carryM);
    } catch (_) {}
  }

  Future<void> _saveCells() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_cellsKey, _claimed.toList());
    } catch (_) {
      // Storage failure must never crash tracking.
    }
  }

  /// Offline activity queue: summaries wait on the phone (synced=false)
  /// until a cloud sync is added.
  Future<void> _saveActivity() async {
    if (_route.length < 2) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList(_activitiesKey) ?? [];
      list.add(jsonEncode({
        'started': _started?.toIso8601String(),
        'ended': DateTime.now().toIso8601String(),
        'distance_km': double.parse(_distanceKm.toStringAsFixed(3)),
        'gps_points': _route.length,
        'new_cells': _newCells,
        'synced': false,
      }));
      await prefs.setStringList(_activitiesKey, list);
    } catch (_) {
      // Never crash on storage failure.
    }
  }

  @override
  void dispose() {
    _gps?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final kingLevel = 1 + (_kingXp ~/ 100);
    final strength = _kingXp % 100; // progress inside the current level (100 XP per level, placeholder)
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            FlutterMap(
              mapController: _map,
              options: MapOptions(
                onMapReady: () => _mapReady = true,
                initialCenter: _center,
                initialZoom: 15,
                interactionOptions: const InteractionOptions(
                  flags: InteractiveFlag.all,
                ),
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.territory.app',
                ),
                PolygonLayer(polygons: _polygons),
                if (_route.length > 1)
                  PolylineLayer(
                    polylines: [
                      Polyline(
                        points: List<LatLng>.from(_route),
                        strokeWidth: 5,
                        color: const Color(0xFFB8F36B),
                      ),
                    ],
                  ),
                MarkerLayer(
                  markers: [
                    Marker(
                      point: _center,
                      width: 18,
                      height: 18,
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFFB8F36B),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                          boxShadow: const [
                            BoxShadow(color: Color(0x8878E06C), blurRadius: 14),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                RichAttributionWidget(
                  attributions: [
                    TextSourceAttribution('© OpenStreetMap contributors'),
                  ],
                ),
              ],
            ),
            Positioned(
              left: 16,
              right: 16,
              top: 14,
              child: _topPanel(strength, kingLevel),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 18,
              child: _bottomPanel(),
            ),
            if (_loading)
              const Center(child: CircularProgressIndicator()),
          ],
        ),
      ),
    );
  }

  List<Polygon> _buildCellPolygons() {
    final polygons = <Polygon>[];
    for (final key in _claimed) {
      final points = HexGrid.boundary(key);
      if (points == null) continue;
      polygons.add(Polygon(
        points: points,
        color: const Color(0x557ED957),
        borderColor: const Color(0xFFB8F36B),
        borderStrokeWidth: 1,
      ));
    }
    return polygons;
  }

  Widget _topPanel(int strength, int kingLevel) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xEE0B1118),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x334D6575)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('TERRITORY',
                  style: TextStyle(
                    letterSpacing: 3,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFFB8F36B),
                  )),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _stat('TERRITORY', '${_claimed.length} cells'),
              const SizedBox(width: 18),
              _stat('COINS', '$_coins'),
              const Spacer(),
              _stat('KING LEVEL', '$kingLevel'),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _stat('DISTANCE', '${_distanceKm.toStringAsFixed(2)} km'),
              const SizedBox(width: 22),
              _stat('XP', '$_kingXp'),
              const Spacer(),
              const Text('Hex cell ≈ 165 m wide', style: TextStyle(fontSize: 10, color: Colors.white38)),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: LinearProgressIndicator(
              value: strength / 100,
              minHeight: 6,
              backgroundColor: const Color(0xFF26323B),
              color: const Color(0xFFB8F36B),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String value) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 9, color: Colors.white54, letterSpacing: 1.2)),
          const SizedBox(height: 3),
          Text(value,
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      );

  Widget _bottomPanel() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xF20B1118),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x334D6575)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(
                _recording ? Icons.radio_button_checked : Icons.gps_fixed,
                color: _recording ? Colors.redAccent : const Color(0xFFB8F36B),
                size: 18,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(_status,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
              Text('${_lastAccuracy.toStringAsFixed(0)}m',
                  style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _toggleRecording,
                  icon: Icon(_recording ? Icons.stop : Icons.play_arrow),
                  label: Text(_recording ? 'FINISH ACTIVITY' : 'START EXPLORING'),
                  style: FilledButton.styleFrom(
                    backgroundColor: _recording
                        ? const Color(0xFFB84242)
                        : const Color(0xFFB8F36B),
                    foregroundColor: const Color(0xFF10160C),
                    padding: const EdgeInsets.symmetric(vertical: 15),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              IconButton.filledTonal(
                onPressed: _prepareLocation,
                icon: const Icon(Icons.my_location),
                tooltip: 'Find my location',
              ),
            ],
          ),
          const SizedBox(height: 3),
          Text('GPS filter: ≤25 m accuracy, 2 fixes per new cell  •  Home location is not hidden in this prototype',
              style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ],
      ),
    );
  }
}
