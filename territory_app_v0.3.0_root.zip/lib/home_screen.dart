import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _green = Color(0xFF12A150);
const _ink = Color(0xFF14191F);
const _muted = Color(0xFF6B7280);
const _line = Color(0xFFE5E7EB);

// Same storage keys as main.dart (kept as copies so this file stands alone).
const _cellsKey = 'territory_hex_cells';
const _coinsKey = 'territory_coins';
const _xpKey = 'territory_king_xp';
const _activitiesKey = 'territory_activities';

class _Snapshot {
  const _Snapshot(this.cells, this.coins, this.xp, this.activities);
  final int cells;
  final int coins;
  final int xp;
  final List<DateTime> activities;
}

/// Home tab: streak, momentum checklist and Kingdom summary.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onRecord, required this.onOpenMap});

  final VoidCallback onRecord;
  final VoidCallback onOpenMap;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  _Snapshot _s = const _Snapshot(0, 0, 0, []);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final acts = <DateTime>[];
      for (final raw in p.getStringList(_activitiesKey) ?? <String>[]) {
        try {
          final m = jsonDecode(raw) as Map<String, dynamic>;
          final t = DateTime.tryParse('${m['started'] ?? ''}');
          if (t != null) acts.add(t.toLocal());
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        _s = _Snapshot(
          (p.getStringList(_cellsKey) ?? <String>[]).length,
          p.getInt(_coinsKey) ?? 0,
          p.getInt(_xpKey) ?? 0,
          acts,
        );
      });
    } catch (_) {
      // Keep showing zeros if storage fails.
    }
  }

  // Weeks start on Monday. 1970-01-05 was a Monday.
  int _weekIndex(DateTime d) =>
      DateTime.utc(d.year, d.month, d.day).difference(DateTime.utc(1970, 1, 5)).inDays ~/ 7;

  int get _streakWeeks {
    final weeks = _s.activities.map(_weekIndex).toSet();
    var w = _weekIndex(DateTime.now());
    if (!weeks.contains(w)) w--; // streak stays alive until the week ends
    var count = 0;
    while (weeks.contains(w)) {
      count++;
      w--;
    }
    return count;
  }

  void _soon() {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(content: Text('Coming soon')));
  }

  Widget _card({required Widget child}) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _line),
        ),
        child: child,
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F5F7),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              _header(),
              const SizedBox(height: 14),
              _streakCard(),
              const SizedBox(height: 14),
              _momentumCard(),
              const SizedBox(height: 14),
              _kingdomCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    Widget action(IconData icon) => IconButton(
          onPressed: _soon,
          icon: Icon(icon, color: _ink),
          visualDensity: VisualDensity.compact,
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
        );
    return Row(
      children: [
        Container(
          width: 44,
          height: 50,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFF1B2733),
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(8),
              bottom: Radius.circular(24),
            ),
            border: Border.all(color: const Color(0xFFE5B83A), width: 3),
          ),
          child: const Text('👑', style: TextStyle(fontSize: 18)),
        ),
        const SizedBox(width: 10),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Territory',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: _ink)),
              Text('Explore • Capture • Grow',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12, color: _muted)),
            ],
          ),
        ),
        action(Icons.add),
        action(Icons.chat_bubble_outline),
        action(Icons.search),
        action(Icons.notifications_none),
      ],
    );
  }

  Widget _streakCard() {
    final weeks = _streakWeeks;
    return _card(
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.local_fire_department, color: Color(0xFFF97316)),
              const SizedBox(width: 8),
              const Text('Your Streak',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: _ink)),
              const Spacer(),
              GestureDetector(
                onTap: _soon,
                child: const Row(
                  children: [
                    Text('View Calendar', style: TextStyle(fontSize: 12, color: _muted)),
                    Icon(Icons.chevron_right, size: 18, color: _muted),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              SizedBox(
                width: 70,
                child: Column(
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Icon(Icons.local_fire_department,
                            size: 64,
                            color: weeks > 0 ? const Color(0xFFF97316) : const Color(0xFFD1D5DB)),
                        Padding(
                          padding: const EdgeInsets.only(top: 14),
                          child: Text('$weeks',
                              style: const TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.w800, color: _ink)),
                        ),
                      ],
                    ),
                    const Text('Weeks', style: TextStyle(fontSize: 12, color: _ink)),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(width: 1, height: 64, color: _line),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  weeks > 0
                      ? 'Keep it going. Log an activity this week.'
                      : 'Start your streak by logging an activity.',
                  style: const TextStyle(fontSize: 13, color: _ink),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: widget.onRecord,
                icon: const Icon(Icons.radio_button_checked, size: 16),
                label: const Text('Record now'),
                style: FilledButton.styleFrom(
                  backgroundColor: _green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  shape: const StadiumBorder(),
                  textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < 3; i++)
                Container(
                  width: 7,
                  height: 7,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: i == 0 ? _green : const Color(0xFFD1D5DB),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _momentumCard() {
    final firstDone = _s.activities.isNotEmpty;
    final done = firstDone ? 1 : 0; // the other 3 need social/device features
    return _card(
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.flag, color: _green),
              const SizedBox(width: 8),
              const Expanded(
                child: Text('Keep that momentum going!',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: _ink)),
              ),
              Text('$done / 4',
                  style: const TextStyle(fontWeight: FontWeight.w700, color: _ink)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              for (var i = 0; i < 4; i++)
                Expanded(
                  child: Container(
                    height: 6,
                    margin: EdgeInsets.only(right: i == 3 ? 0 : 4),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      color: i < done ? _green : const Color(0xFFE5E7EB),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          _task(Icons.directions_run, 'Upload your first activity',
              'You can record it right in the app.', firstDone, widget.onRecord),
          const SizedBox(height: 8),
          _task(Icons.groups, 'Follow three people (0/3)',
              'Find friends and fan favorites to follow.', false, _soon),
          const SizedBox(height: 8),
          _task(Icons.watch, 'Connect a device',
              'Sync a watch or fitness tracker.', false, _soon),
          const SizedBox(height: 8),
          InkWell(
            onTap: _soon,
            borderRadius: BorderRadius.circular(16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5EC),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                children: [
                  Icon(Icons.add_circle, color: _green),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text('Add a profile picture',
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: _ink)),
                  ),
                  Icon(Icons.chevron_right, color: _ink),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _task(IconData icon, String title, String subtitle, bool done, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _line),
        ),
        child: Row(
          children: [
            Icon(done ? Icons.check_circle : Icons.circle_outlined,
                color: done ? _green : const Color(0xFFD1D5DB)),
            const SizedBox(width: 10),
            Icon(icon, color: _green, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w700, color: _ink)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: _muted)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: _ink),
          ],
        ),
      ),
    );
  }

  Widget _kingdomCard() {
    final level = 1 + (_s.xp ~/ 100);
    final strength = _s.xp % 100;
    return _card(
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.location_on, color: _green),
              const SizedBox(width: 8),
              const Text('Your Kingdom',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: _ink)),
              const Spacer(),
              GestureDetector(
                onTap: widget.onOpenMap,
                child: const Row(
                  children: [
                    Text('View Map', style: TextStyle(fontSize: 12, color: _muted)),
                    Icon(Icons.chevron_right, size: 18, color: _muted),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Container(
                width: 110,
                height: 96,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF86D08A), Color(0xFF3F9B4F)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: const Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(Icons.castle, size: 54, color: Colors.white),
                    Positioned(left: 8, bottom: 8, child: Icon(Icons.park, color: Color(0xFF1F6B33))),
                    Positioned(right: 8, bottom: 8, child: Icon(Icons.park, color: Color(0xFF1F6B33))),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(width: 1, height: 80, color: _line),
              Expanded(child: _stat(Icons.grid_view_rounded, 'Territory', '${_s.cells} Cells')),
              Expanded(child: _stat(Icons.bolt, 'Strength', '$strength%')),
              Expanded(child: _stat(Icons.star, 'EXP', '${_s.xp}')),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text('King Lv $level   •   🪙 ${_s.coins}',
                  style: const TextStyle(fontWeight: FontWeight.w700, color: _ink)),
              const Spacer(),
              const Text('1 cell ≈ 0.02 km²',
                  style: TextStyle(fontSize: 11, color: _muted)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stat(IconData icon, String label, String value) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _green, size: 24),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 12, color: _ink)),
          const SizedBox(height: 2),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(value,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: _ink)),
          ),
        ],
      );
}
